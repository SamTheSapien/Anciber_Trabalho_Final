<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Port Model
 *
 * @method \App\Model\Entity\Port newEmptyEntity()
 * @method \App\Model\Entity\Port newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Port[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Port get($primaryKey, $options = [])
 * @method \App\Model\Entity\Port findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Port patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Port[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Port|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Port saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Port[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Port[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Port[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Port[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class PortTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('port');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('number')
            ->maxLength('number', 10)
            ->requirePresence('number', 'create')
            ->notEmptyString('number');

        $validator
            ->scalar('state')
            ->maxLength('state', 100)
            ->allowEmptyString('state');

        $validator
            ->scalar('service')
            ->maxLength('service', 100)
            ->allowEmptyString('service');

        $validator
            ->scalar('version')
            ->maxLength('version', 100)
            ->allowEmptyString('version');

        $validator
            ->scalar('info')
            ->maxLength('info', 100)
            ->allowEmptyString('info');

        return $validator;
    }
}
