<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Scan Controller
 *
 * @property \App\Model\Table\ScanTable $Scan
 * @method \App\Model\Entity\Scan[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ScanController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $scan = $this->paginate($this->Scan);

        $this->set(compact('scan'));
    }

    /**
     * View method
     *
     * @param string|null $id Scan id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $scan = $this->Scan->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('scan'));
    }

    /**
	My python program - Samuel
    */
     public function nmap()
	{
	exec('python3 /var/www/cakephp/app/webroot/scanner.py');
	return $this->redirect(['action' => 'index']);
	}

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $scan = $this->Scan->newEmptyEntity();
        if ($this->request->is('post')) {
            $scan = $this->Scan->patchEntity($scan, $this->request->getData());
            if ($this->Scan->save($scan)) {
                $this->Flash->success(__('The scan has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The scan could not be saved. Please, try again.'));
        }
        $this->set(compact('scan'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Scan id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $scan = $this->Scan->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $scan = $this->Scan->patchEntity($scan, $this->request->getData());
            if ($this->Scan->save($scan)) {
                $this->Flash->success(__('The scan has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The scan could not be saved. Please, try again.'));
        }
        $this->set(compact('scan'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Scan id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $scan = $this->Scan->get($id);
        if ($this->Scan->delete($scan)) {
            $this->Flash->success(__('The scan has been deleted.'));
        } else {
            $this->Flash->error(__('The scan could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
