<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ScanFixture
 */
class ScanFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'scan';
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'Data' => ['type' => 'date', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'Hora' => ['type' => 'timestamp', 'length' => null, 'precision' => null, 'null' => true, 'default' => 'current_timestamp()', 'comment' => ''],
        'Descricao' => ['type' => 'string', 'length' => 300, 'null' => true, 'default' => 'No Description', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'comandline' => ['type' => 'string', 'length' => 300, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'file' => ['type' => 'binary', 'length' => 16777215, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'Data' => '2020-12-13',
                'Hora' => 1607881413,
                'Descricao' => 'Lorem ipsum dolor sit amet',
                'comandline' => 'Lorem ipsum dolor sit amet',
                'file' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
