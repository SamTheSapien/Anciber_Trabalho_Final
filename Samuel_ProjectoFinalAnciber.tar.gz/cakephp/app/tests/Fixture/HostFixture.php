<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * HostFixture
 */
class HostFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'host';
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'host' => ['type' => 'string', 'length' => 100, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'opsystem' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'kernel' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'ports' => ['type' => 'string', 'length' => 500, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'host' => 'Lorem ipsum dolor sit amet',
                'opsystem' => 'Lorem ipsum dolor sit amet',
                'kernel' => 'Lorem ipsum dolor sit amet',
                'ports' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
