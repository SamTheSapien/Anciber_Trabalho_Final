<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PortFixture
 */
class PortFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'port';
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'number' => ['type' => 'string', 'length' => 10, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'state' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'service' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'version' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        'info' => ['type' => 'string', 'length' => 100, 'null' => true, 'default' => 'Unknow', 'collate' => 'utf8mb4_general_ci', 'comment' => '', 'precision' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'number' => 'Lorem ip',
                'state' => 'Lorem ipsum dolor sit amet',
                'service' => 'Lorem ipsum dolor sit amet',
                'version' => 'Lorem ipsum dolor sit amet',
                'info' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
