<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ScanTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ScanTable Test Case
 */
class ScanTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\ScanTable
     */
    protected $Scan;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Scan',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Scan') ? [] : ['className' => ScanTable::class];
        $this->Scan = $this->getTableLocator()->get('Scan', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Scan);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
