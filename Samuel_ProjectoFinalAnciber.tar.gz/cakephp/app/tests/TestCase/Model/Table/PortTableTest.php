<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PortTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PortTable Test Case
 */
class PortTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\PortTable
     */
    protected $Port;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Port',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Port') ? [] : ['className' => PortTable::class];
        $this->Port = $this->getTableLocator()->get('Port', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Port);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
