<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\HostTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\HostTable Test Case
 */
class HostTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\HostTable
     */
    protected $Host;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Host',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Host') ? [] : ['className' => HostTable::class];
        $this->Host = $this->getTableLocator()->get('Host', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Host);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
