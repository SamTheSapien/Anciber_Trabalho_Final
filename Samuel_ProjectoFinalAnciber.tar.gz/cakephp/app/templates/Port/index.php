<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Port[]|\Cake\Collection\CollectionInterface $port
 */
?>
<div class="port index content">
<?= $this->Html->link(__('New Port'), ['action' => 'add'], ['class' => 'button float-right']) ?>
   
<?= $this->Html->link(__('Hosts'), ['controller'=>'Host','action'=>'index'], ['class' => 'button float-right'])?>
 <?= $this->Html->link(__('Scans'), ['controller'=>'Scan','action'=>'index'], ['class' => 'button float-right'])?>
    <h3><?= __('Port') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('number') ?></th>
                    <th><?= $this->Paginator->sort('state') ?></th>
                    <th><?= $this->Paginator->sort('service') ?></th>
                    <th><?= $this->Paginator->sort('version') ?></th>
                    <th><?= $this->Paginator->sort('info') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($port as $port): ?>
                <tr>
                    <td><?= $this->Number->format($port->id) ?></td>
                    <td><?= h($port->number) ?></td>
                    <td><?= h($port->state) ?></td>
                    <td><?= h($port->service) ?></td>
                    <td><?= h($port->version) ?></td>
                    <td><?= h($port->info) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $port->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $port->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $port->id], ['confirm' => __('Are you sure you want to delete # {0}?', $port->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
