<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Port $port
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $port->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $port->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Port'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="port form content">
            <?= $this->Form->create($port) ?>
            <fieldset>
                <legend><?= __('Edit Port') ?></legend>
                <?php
                    echo $this->Form->control('number');
                    echo $this->Form->control('state');
                    echo $this->Form->control('service');
                    echo $this->Form->control('version');
                    echo $this->Form->control('info');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
