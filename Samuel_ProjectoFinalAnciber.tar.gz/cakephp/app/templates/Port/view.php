<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Port $port
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Port'), ['action' => 'edit', $port->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Port'), ['action' => 'delete', $port->id], ['confirm' => __('Are you sure you want to delete # {0}?', $port->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Port'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Port'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="port view content">
            <h3><?= h($port->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Number') ?></th>
                    <td><?= h($port->number) ?></td>
                </tr>
                <tr>
                    <th><?= __('State') ?></th>
                    <td><?= h($port->state) ?></td>
                </tr>
                <tr>
                    <th><?= __('Service') ?></th>
                    <td><?= h($port->service) ?></td>
                </tr>
                <tr>
                    <th><?= __('Version') ?></th>
                    <td><?= h($port->version) ?></td>
                </tr>
                <tr>
                    <th><?= __('Info') ?></th>
                    <td><?= h($port->info) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($port->id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
