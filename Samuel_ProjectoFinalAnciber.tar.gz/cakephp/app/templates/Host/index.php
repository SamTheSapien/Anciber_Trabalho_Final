<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Host[]|\Cake\Collection\CollectionInterface $host
 */
?>
<div class="host index content">
    <?= $this->Html->link(__('New Host'), ['action' => 'add'], ['class' => 'button float-right']) ?>
<?= $this->Html->link(__('Ports'), ['controller'=>'Port','action'=>'index'], ['class' => 'button float-right'])?>
<?= $this->Html->link(__('Scans'), ['controller'=>'Scan','action'=>'index'], ['class' => 'button float-right'])?>
    <h3><?= __('Host') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('host') ?></th>
                    <th><?= $this->Paginator->sort('opsystem') ?></th>
                    <th><?= $this->Paginator->sort('kernel') ?></th>
                    <th><?= $this->Paginator->sort('ports') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($host as $host): ?>
                <tr>
                    <td><?= $this->Number->format($host->id) ?></td>
                    <td><?= h($host->host) ?></td>
                    <td><?= h($host->opsystem) ?></td>
                    <td><?= h($host->kernel) ?></td>
                    <td><?= h($host->ports) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $host->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $host->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $host->id], ['confirm' => __('Are you sure you want to delete # {0}?', $host->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
