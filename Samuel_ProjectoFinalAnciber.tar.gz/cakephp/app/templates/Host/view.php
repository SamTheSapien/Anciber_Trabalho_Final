<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Host $host
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Host'), ['action' => 'edit', $host->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Host'), ['action' => 'delete', $host->id], ['confirm' => __('Are you sure you want to delete # {0}?', $host->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Host'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Host'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="host view content">
            <h3><?= h($host->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Host') ?></th>
                    <td><?= h($host->host) ?></td>
                </tr>
                <tr>
                    <th><?= __('Opsystem') ?></th>
                    <td><?= h($host->opsystem) ?></td>
                </tr>
                <tr>
                    <th><?= __('Kernel') ?></th>
                    <td><?= h($host->kernel) ?></td>
                </tr>
                <tr>
                    <th><?= __('Ports') ?></th>
                    <td><?= h($host->ports) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($host->id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
