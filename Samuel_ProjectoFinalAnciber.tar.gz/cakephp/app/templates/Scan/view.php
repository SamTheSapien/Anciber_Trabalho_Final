<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Scan $scan
 */
use Cake\Filesystem\File;
use Cake\Filesystem\Folder;
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Scan'), ['action' => 'edit', $scan->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Scan'), ['action' => 'delete', $scan->id], ['confirm' => __('Are you sure you want to delete # {0}?', $scan->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Scan'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
	<!--
            <?= $this->Html->link(__('New Scan'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
	-->
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="scan view content">
            <h3><?= h($scan->id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Descricao') ?></th>
                    <td><?= h($scan->Descricao) ?></td>
                </tr>
                <tr>
                    <th><?= __('Comandline') ?></th>
                    <td><?= h($scan->comandline) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($scan->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Data') ?></th>
                    <td><?= h($scan->Data) ?></td>
                </tr>
                <tr>
                    <th><?= __('Hora') ?></th>
                    <td><?= h($scan->Hora) ?></td>
                </tr>
		 <tr>
                    <th><?= __('File') ?></th>
                    <td><?php
		$dir = new Folder(WWW_ROOT.'scans');
		$filename = $dir->find($this->Number->format($scan->id).'-scan.txt');
	        	//debug($filename);
			$file = new File($dir->pwd() . DS . $filename[0]);
               		$contents = $file->read();
			echo nl2br($contents);
                	$file->close();
 ?></td>
                </tr>

            </table>
        </div>
    </div>
</div>
