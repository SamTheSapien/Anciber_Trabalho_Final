<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Scan[]|\Cake\Collection\CollectionInterface $scan
 */
?>
<div class="scan index content">
	<!-- 
<?= $this->Html->link(__('New Scan'), ['action' => 'add'], ['class' => 'button float-right']) ?>
-->
<?=
	$this->Html->link(__('New Scan'), ['action' => 'nmap'], ['class' => 'button float-right'])

?>
   <?= $this->Html->link(__('Hosts'), ['controller'=>'Host','action'=>'index'], ['class' => 'button float-right']) ?>
<?= $this->Html->link(__('Ports'), ['controller'=>'Port','action'=>'index'], ['class' => 'button float-right']) ?>

       <h3><?= __('Scan') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('Data') ?></th>
                    <th><?= $this->Paginator->sort('Hora') ?></th>
                    <th><?= $this->Paginator->sort('Descricao') ?></th>
                    <th><?= $this->Paginator->sort('comandline') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scan as $scan): ?>
                <tr>
                    <td><?= $this->Number->format($scan->id) ?></td>
                    <td><?= h($scan->Data) ?></td>
                    <td><?= h($scan->Hora) ?></td>
                    <td><?= h($scan->Descricao) ?></td>
                    <td><?= h($scan->comandline) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $scan->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $scan->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $scan->id], ['confirm' => __('Are you sure you want to delete # {0}?', $scan->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
