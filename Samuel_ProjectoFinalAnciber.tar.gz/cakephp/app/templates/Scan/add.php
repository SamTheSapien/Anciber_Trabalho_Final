<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Scan $scan
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Scan'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="scan form content">
            <?= $this->Form->create($scan) ?>
            <fieldset>
                <legend><?= __('Add Scan') ?></legend>
                <?php
                    echo $this->Form->control('Data', ['empty' => true]);
                    echo $this->Form->control('Hora');
                    echo $this->Form->control('Descricao');
                    echo $this->Form->control('comandline');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
